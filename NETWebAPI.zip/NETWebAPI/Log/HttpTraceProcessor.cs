using System;
using System.Diagnostics;
using System.IO;
using Microsoft.AspNetCore.WebUtilities;
using OpenTelemetry;
using Microsoft.AspNetCore.Http;

public class HttpTraceProcessor : BaseProcessor<Activity>
{
    private static readonly object FileLock = new();

    private readonly string _filePath =
        $@"C:\VSCode WebAPP\OpenTelemetryLogs\HttpTrace_{DateTime.Now:yyyy-MM-dd}.txt";

    public override void OnEnd(Activity activity)
    {
        if (activity.Kind != ActivityKind.Server)
            return;

        var statusValue =
            activity.GetTagItem("http.response.status_code");

        if (statusValue == null)
            return;

        int statusCode = Convert.ToInt32(statusValue);

        string endpoint =
     activity.GetTagItem("url.path")?.ToString()
     + activity.GetTagItem("url.query")?.ToString()
     ?? activity.GetTagItem("http.target")?.ToString()
     ?? activity.GetTagItem("http.route")?.ToString()
     ?? activity.DisplayName;

        string method =
            activity.GetTagItem("http.request.method")?.ToString()
            ?? activity.GetTagItem("http.method")?.ToString()
            ?? "HTTP";

        string statusMessage =
            ReasonPhrases.GetReasonPhrase(statusCode);

        string userAgent =
          activity.GetTagItem("user_agent.original")?.ToString()
          ?? activity.GetTagItem("http.user_agent")?.ToString()
          ?? activity.GetTagItem("client.user_agent")?.ToString()
          ?? "Unknown";

        string referer =
            activity.GetTagItem("client.referer")?.ToString()
            ?? "";

        string sourceTool;


        if (userAgent.Contains("Postman", StringComparison.OrdinalIgnoreCase))
        {
            sourceTool = "Postman";
        }
        else if (referer.Contains("swagger", StringComparison.OrdinalIgnoreCase))
        {
            sourceTool = "Swagger UI";
        }
        else if (userAgent.Contains("Chrome/", StringComparison.OrdinalIgnoreCase))
        {
            sourceTool = "Google Chrome";
        }
        else
        {
            sourceTool = "Unknown / Other Client";
        }

        // Skip Swagger and browser resource requests
        if (endpoint.Contains("/swagger", StringComparison.OrdinalIgnoreCase) ||
            endpoint.EndsWith(".js", StringComparison.OrdinalIgnoreCase) ||
            endpoint.EndsWith(".css", StringComparison.OrdinalIgnoreCase) ||
            endpoint.EndsWith(".png", StringComparison.OrdinalIgnoreCase) ||
            endpoint.EndsWith(".ico", StringComparison.OrdinalIgnoreCase))
        {
            return;
        }

        string pcUserName = Environment.UserName;
        string pcName = Environment.MachineName;

        string completeUrl =
            activity.GetTagItem("url.full")?.ToString()
            ?? activity.GetTagItem("http.url")?.ToString()
            ?? (
                activity.GetTagItem("url.scheme")?.ToString() != null &&
                activity.GetTagItem("server.address")?.ToString() != null &&
                activity.GetTagItem("url.path")?.ToString() != null
                    ? $"{activity.GetTagItem("url.scheme")}://{activity.GetTagItem("server.address")}{(activity.GetTagItem("server.port") != null ? ":" + activity.GetTagItem("server.port") : "")}{activity.GetTagItem("url.path")}{activity.GetTagItem("url.query")}"
                    : "Unknown"
            );

        string ipAddress =
            System.Net.NetworkInformation.NetworkInterface
                .GetAllNetworkInterfaces()
                .Where(n => n.OperationalStatus ==
                            System.Net.NetworkInformation.OperationalStatus.Up)
                .SelectMany(n => n.GetIPProperties().UnicastAddresses)
                .Where(a => a.Address.AddressFamily ==
                            System.Net.Sockets.AddressFamily.InterNetwork &&
                            !System.Net.IPAddress.IsLoopback(a.Address))
                .Select(a => a.Address.ToString())
                .FirstOrDefault() ?? "IPv4 not available";

        string logMessage =
            $"Date/Time      : {DateTime.Now:yyyy-MM-dd HH:mm:ss}{Environment.NewLine}" +
            $"Endpoint       : {method} {endpoint}{Environment.NewLine}" +
            $"Complete URL   : {completeUrl}{Environment.NewLine}" +
            $"Status Code    : {statusCode}{Environment.NewLine}" +
            $"Status Message : {statusMessage}{Environment.NewLine}" +
            $"Duration       : {activity.Duration.TotalMilliseconds:F2} ms{Environment.NewLine}" +
            $"Source Tool    : {sourceTool}{Environment.NewLine}" +
            $"User-Agent     : {userAgent}{Environment.NewLine}" +
            $"PC User Name   : {pcUserName}{Environment.NewLine}" +
            $"PC Name        : {pcName}{Environment.NewLine}" +
            $"IP Address     : {ipAddress}{Environment.NewLine}" +
            "----------------------------------------" + Environment.NewLine + Environment.NewLine;

        try
        {
            lock (FileLock)
            {
                Directory.CreateDirectory(
                    Path.GetDirectoryName(_filePath)!);

                File.AppendAllText(_filePath, logMessage);
            }
        }
        catch (IOException ex)
        {
            Console.WriteLine($"Trace file write failed: {ex.Message}");
        }
        catch (UnauthorizedAccessException ex)
        {
            Console.WriteLine($"Trace file access denied: {ex.Message}");
        }
    }
}