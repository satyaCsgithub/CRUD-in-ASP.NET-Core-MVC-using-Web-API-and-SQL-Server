using Asp.Versioning;
using System.Reflection;
using Microsoft.EntityFrameworkCore;
using NETWebAPI.Data;
using NETWebAPI.Filters;
using Microsoft.AspNetCore.Authentication;
using Microsoft.OpenApi;
using Microsoft.AspNetCore.RateLimiting;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

//builder.Services.AddControllers();

//Apply Content Negotiation

// builder.Services.AddControllers(options => 
// { 
//     options.RespectBrowserAcceptHeader = true;
// }).AddXmlSerializerFormatters();

// builder.Services.AddControllers(options => 
// { 
//     options.RespectBrowserAcceptHeader = true;
//     options.ReturnHttpNotAcceptable = true;
// }).AddXmlSerializerFormatters();

// builder.Services.AddControllers(options =>
// {
//     options.RespectBrowserAcceptHeader = true;
//     options.ReturnHttpNotAcceptable = true;
//     options.OutputFormatters.Add(new PlainTextOutputFormatter());
// })
// .AddXmlSerializerFormatters();

builder.Services.AddControllers(options =>
{
    options.RespectBrowserAcceptHeader = true;
    options.ReturnHttpNotAcceptable = true;
    options.OutputFormatters.Add(new PlainTextOutputFormatter());
    options.OutputFormatters.Add(new CsvOutputFormatter());
}).AddXmlSerializerFormatters();

//Apply Content Negotiation

// Learn more about configuring OpenAPI at https://aka.ms/aspnet/openapi
builder.Services.AddOpenApi();

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    var xmlFilename =
        $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";

    options.IncludeXmlComments(
        Path.Combine(AppContext.BaseDirectory, xmlFilename));

    options.AddSecurityDefinition("BasicAuth",
        new OpenApiSecurityScheme
        {
            Type = SecuritySchemeType.Http,
            Scheme = "basic",
            In = ParameterLocation.Header,
            Description = "Enter Username and Password"
        });

    options.AddSecurityRequirement(document =>
        new OpenApiSecurityRequirement
        {
            [new OpenApiSecuritySchemeReference(
                "BasicAuth",
                document)] = new List<string>()
        });

    // API VERSIONING
    options.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "My API",
        Version = "v1"
    });

    options.SwaggerDoc("v2", new OpenApiInfo
    {
        Title = "My API",
        Version = "v2"
    });

    options.DocInclusionPredicate((docName, apiDesc) =>
    {
        return apiDesc.GroupName == docName;
    });
});
//Basic Authentication Swagger code is here

builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(
        builder.Configuration.GetConnectionString("DefaultConnection")
    )
);

//Define a named policy
builder.Services.AddCors(Options =>
{
    Options.AddPolicy("AllowFrontEnd", policy =>
    {
        policy.WithOrigins("https://myapp.com", "http://localhost:5028")
              .WithMethods("GET", "POST", "PUT", "DELETE")
              .WithHeaders("Content-Type", "application/json");
    });
});

// builder.Services.AddCors(options =>{
//     options.AddPolicy("AllowFrontEnd", policy =>
//     {
//         policy.WithOrigins("http://localhost:5028")
//               .AllowAnyMethod()
//               .AllowAnyHeader();
//     });
// });

builder.Services
.AddAuthentication("BasicAuthentication")
.AddScheme<AuthenticationSchemeOptions,
BasicAuthenticationHandler>("BasicAuthentication", null);
builder.Services.AddAuthorization();

//Rate limit
builder.Services.AddRateLimiter(options =>
{
    options.AddFixedWindowLimiter("fixed", limiter =>
    {
        limiter.PermitLimit = 5;
        limiter.Window = TimeSpan.FromSeconds(30);
        limiter.QueueLimit = 0;
    });

    options.OnRejected = async (context, cancellationToken) =>
    {
        context.HttpContext.Response.StatusCode = 429;
        context.HttpContext.Response.ContentType = "application/json";

        await context.HttpContext.Response.WriteAsJsonAsync(
            new
            {
                success = false,
                message = "Rate limit exceeded. Please wait 30 seconds before trying again."
            },
            cancellationToken);
    };
});
//Rate limit

//Output Caching
builder.Services.AddOutputCache(options =>
{
    options.AddPolicy("ApiCache", policy =>
    {
        policy.Expire(TimeSpan.FromSeconds(30));
    });
});
//Output Caching

builder.Services.AddExceptionHandler<GlobalExceptionHandler>();
builder.Services.AddProblemDetails();
//ApiVersion
builder.Services
    .AddApiVersioning(options =>
    {
        options.DefaultApiVersion = new ApiVersion(1, 0);
        options.AssumeDefaultVersionWhenUnspecified = true;
        options.ReportApiVersions = true;

        options.ApiVersionReader =
            new UrlSegmentApiVersionReader();
    })
    .AddMvc()
    .AddApiExplorer(options =>
    {
        options.GroupNameFormat = "'v'VVV";
        options.SubstituteApiVersionInUrl = true;
    });
//ApiVersion
var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();

    app.UseSwagger();
    app.UseSwaggerUI(c =>
{
    c.SwaggerEndpoint(
        "/swagger/v1/swagger.json",
        "My API V1");

    c.SwaggerEndpoint(
        "/swagger/v2/swagger.json",
        "My API V2");
});
}

app.UseExceptionHandler();
app.UseHttpsRedirection();
//Must be placed before UseAuthorization
app.UseCors("AllowFrontEnd");
app.UseStaticFiles();
app.UseAuthentication();
app.UseAuthorization();
app.UseRateLimiter();
app.UseOutputCache();
//app.UseMiddleware<CustomCacheMiddleware>();
app.MapControllers();
app.Run();
