using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using NETWebAPI.Data;
using NETWebAPI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.AspNetCore.OutputCaching;
using Asp.Versioning;

namespace NETWebAPI.Controllers
{
    [Authorize]
    [ApiController]
    [ApiVersion(1.0)]
    // [Route("api/[controller]")]
    [Route("api/v{version:apiVersion}/[controller]")]
    [EnableRateLimiting("fixed")]
    [EnableCors("AllowFrontEnd")] //applied to whole controller
    public class EmployeesController : ControllerBase
    {
        private readonly AppDbContext _context;

        public EmployeesController(AppDbContext context)
        {
            _context = context;
        }

        // GET api/employees
        //[Authorize]
        //[EnableCors("AllowFrontEnd")] //applied to specific http methods
        //[DisableCors]
        [HttpGet]
        //[OutputCache(PolicyName = "ApiCache")]
        public async Task<ActionResult<IEnumerable<Employee>>> GetEmployees()
        {
            return await _context.Employees.ToListAsync();
        }

        // GET api/employees/id
        [HttpGet("{id}")]
        //[MapToApiVersion(1.0)]
        //[DisableCors] //opt-out a specific action
        public async Task<ActionResult<Employee>> GetEmployeeById(int id)
        {
            var employee = await _context.Employees.FindAsync(id);

            if (employee == null)
            {
                return NotFound(new
                {
                    message = $"Employee with ID {id} not found."
                });
            }
            return employee;
        }
        // POST: api/employees
        [HttpPost]
        public async Task<ActionResult<Employee>> CreateEmployee([FromForm] Employee employee)
        {
            employee.CreatedAt = DateTime.Now;

            if (employee.EmployeeImage != null && employee.EmployeeImage.Length > 0)
            {
                var uploadFolder = Path.Combine(
                    Directory.GetCurrentDirectory(),
                    "wwwroot",
                    "uploads");

                if (!Directory.Exists(uploadFolder))
                {
                    Directory.CreateDirectory(uploadFolder);
                }

                var fileName = Guid.NewGuid().ToString() +
                               Path.GetExtension(employee.EmployeeImage.FileName);

                var filePath = Path.Combine(uploadFolder, fileName);

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await employee.EmployeeImage.CopyToAsync(stream);
                }

                employee.ImagePath = "uploads/" + fileName;
            }
            else
            {
                employee.ImagePath = "uploads/NoImage.jpg";
            }

            _context.Employees.Add(employee);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetEmployeeById),
                new { id = employee.EmployeeID }, employee);
        }

        // PUT: api/employees/14
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateEmployee(
            int id,
            [FromForm] Employee employee)
        {
            if (id != employee.EmployeeID)
            {
                return BadRequest();
            }

            var existingEmployee = await _context.Employees.FindAsync(id);

            if (existingEmployee == null)
            {
                return NotFound();
            }

            // Update employee details
            existingEmployee.FirstName = employee.FirstName;
            existingEmployee.LastName = employee.LastName;
            existingEmployee.Email = employee.Email;
            existingEmployee.HireDate = employee.HireDate;
            existingEmployee.Salary = employee.Salary;

            // Upload new image (if selected)
            if (employee.EmployeeImage != null && employee.EmployeeImage.Length > 0)
            {
                var uploadFolder = Path.Combine(
                    Directory.GetCurrentDirectory(),
                    "wwwroot",
                    "uploads");

                if (!Directory.Exists(uploadFolder))
                {
                    Directory.CreateDirectory(uploadFolder);
                }

                // Delete old image (except NoImage.jpg)
                if (!string.IsNullOrEmpty(existingEmployee.ImagePath) &&
                    existingEmployee.ImagePath != "uploads/NoImage.jpg")
                {
                    var oldImage = Path.Combine(
                        Directory.GetCurrentDirectory(),
                        "wwwroot",
                        existingEmployee.ImagePath.Replace("/", Path.DirectorySeparatorChar.ToString()));

                    if (System.IO.File.Exists(oldImage))
                    {
                        System.IO.File.Delete(oldImage);
                    }
                }

                // Save new image
                var fileName = Guid.NewGuid().ToString() +
                               Path.GetExtension(employee.EmployeeImage.FileName);

                var filePath = Path.Combine(uploadFolder, fileName);

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await employee.EmployeeImage.CopyToAsync(stream);
                }

                existingEmployee.ImagePath = "uploads/" + fileName;
            }

            existingEmployee.UpdatedAt = DateTime.Now;

            await _context.SaveChangesAsync();

            return Ok(existingEmployee);
        }

        // DELETE: api/employees/14

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteEmployee(int id)
        {
            try
            {
                var employee = await _context.Employees.FindAsync(id);

                if (employee == null)
                {
                    return NotFound(new
                    {
                        message = $"Employee with ID {id} not found."
                    });
                }

                // Delete employee image (except NoImage.jpg)
                if (!string.IsNullOrEmpty(employee.ImagePath) &&
                    employee.ImagePath != "uploads/NoImage.jpg")
                {
                    var imagePath = Path.Combine(
                        Directory.GetCurrentDirectory(),
                        "wwwroot",
                        employee.ImagePath.Replace("/", Path.DirectorySeparatorChar.ToString()));

                    if (System.IO.File.Exists(imagePath))
                    {
                        System.IO.File.Delete(imagePath);
                    }
                }

                // Delete employee from database
                _context.Employees.Remove(employee);
                await _context.SaveChangesAsync();

                return Ok(new
                {
                    message = $"Employee with ID {id} deleted successfully."
                });
            }
            catch (Exception)
            {
                return StatusCode(500, new
                {
                    message = "An error occurred while deleting the employee."
                });
            }
        }
    }
}