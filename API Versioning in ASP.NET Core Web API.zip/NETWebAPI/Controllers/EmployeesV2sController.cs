using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using NETWebAPI.Data;
using NETWebAPI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.AspNetCore.OutputCaching;
using Asp.Versioning;

namespace NETWebAPI.Controllers
{
    [Authorize]
    [ApiController]
    [ApiVersion(2.0)]  
    // [Route("api/[controller]")]
    [Route("api/v{version:apiVersion}/[controller]")]
    [EnableRateLimiting("fixed")]
    [EnableCors("AllowFrontEnd")] //applied to whole controller
    public class EmployeeV2sController : ControllerBase
    {
        private readonly AppDbContext _context;

        public EmployeeV2sController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet("{id}")]
        //[MapToApiVersion(2.0)]
        public async Task<IActionResult> GetEmployeeByIdV2(int id)
        {
            var employee = await _context.Employees.FindAsync(id);

            if (employee == null)
            {
                return NotFound(new
                {
                    message = $"Employee with ID {id} not found."
                });
            }

            return Ok(new
            {
                version = "v2",
                employeeId = employee.EmployeeID,
                firstName = employee.FirstName,
                lastName = employee.LastName,
                email = employee.Email,
                message = "Employee data from API Version 2"
            });
        }
    }
}