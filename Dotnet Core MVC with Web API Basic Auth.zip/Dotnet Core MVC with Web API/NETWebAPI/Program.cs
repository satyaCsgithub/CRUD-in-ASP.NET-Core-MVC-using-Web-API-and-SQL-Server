using System.Reflection;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using NETWebAPI.Data;
using NETWebAPI.Filters;
using Microsoft.AspNetCore.Authentication;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

//builder.Services.AddControllers();

//Apply Content Negotiation

// builder.Services.AddControllers(options => 
// { 
//     options.RespectBrowserAcceptHeader = true;
// }).AddXmlSerializerFormatters();

// builder.Services.AddControllers(options => 
// { 
//     options.RespectBrowserAcceptHeader = true;
//     options.ReturnHttpNotAcceptable = true;
// }).AddXmlSerializerFormatters();

// builder.Services.AddControllers(options =>
// {
//     options.RespectBrowserAcceptHeader = true;
//     options.ReturnHttpNotAcceptable = true;
//     options.OutputFormatters.Add(new PlainTextOutputFormatter());
// })
// .AddXmlSerializerFormatters();

builder.Services.AddControllers(options => 
{
    options.RespectBrowserAcceptHeader = true;
    options.ReturnHttpNotAcceptable = true;
    options.OutputFormatters.Add(new PlainTextOutputFormatter());
    options.OutputFormatters.Add(new CsvOutputFormatter());
}).AddXmlSerializerFormatters();

//Apply Content Negotiation

// Learn more about configuring OpenAPI at https://aka.ms/aspnet/openapi
builder.Services.AddOpenApi();

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    // using System.Reflection;
var xmlFilename = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
options.IncludeXmlComments(Path.Combine(AppContext.BaseDirectory, xmlFilename));

});

builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(
        builder.Configuration.GetConnectionString("DefaultConnection")
    )
);

//Define a named policy
builder.Services.AddCors(Options =>{
    Options.AddPolicy("AllowFrontEnd", policy =>
    {
        policy.WithOrigins("https://myapp.com", "http://localhost:5028")
              .WithMethods ("GET", "POST","PUT","DELETE")
              .WithHeaders ("Content-Type", "application/json");
    });
});

// builder.Services.AddCors(options =>{
//     options.AddPolicy("AllowFrontEnd", policy =>
//     {
//         policy.WithOrigins("http://localhost:5028")
//               .AllowAnyMethod()
//               .AllowAnyHeader();
//     });
// });

builder.Services
.AddAuthentication("BasicAuthentication")
.AddScheme<AuthenticationSchemeOptions,
BasicAuthenticationHandler>("BasicAuthentication", null);
builder.Services.AddAuthorization();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();

    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        c.SwaggerEndpoint("/swagger/v1/swagger.json", "My API V1");
    });
}

app.UseHttpsRedirection();

//Must be placed before UseAuthorization
app.UseCors("AllowFrontEnd");

app.UseStaticFiles();

app.UseHttpsRedirection();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

app.UseExceptionHandler("/error");

app.Run();
