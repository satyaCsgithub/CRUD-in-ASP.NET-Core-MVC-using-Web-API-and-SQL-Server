using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
public class Employee
{
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int EmployeeId { get; set; }

        [Required]
        [StringLength(50)]
        public string FirstName { get; set; } = null!;

        [Required]
        [StringLength(50)]
        public string LastName { get; set; } = null!;

        [Required]
        [StringLength(100)]
        public string? Email { get; set; }

        [Required]
        [Column(TypeName = "date")]
        public DateTime HireDate { get; set; }

        [Required]
        [Column(TypeName = "decimal(10,2)")]
        public decimal? Salary { get; set; }

        [StringLength(255)]
        public string? ImagePath { get; set; }

        [NotMapped]
        [System.Text.Json.Serialization.JsonIgnore]
        public IFormFile? EmployeeImage { get; set; }

        public DateTime? CreatedAt { get; set; }
        public DateTime? UpdatedAt { get; set; }
}