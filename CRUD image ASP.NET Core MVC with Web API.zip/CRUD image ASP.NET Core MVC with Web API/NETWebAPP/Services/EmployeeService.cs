using System.Net.Http.Json;

public class EmployeeService
{
    private readonly HttpClient _httpClient;

    public EmployeeService(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public async Task<List<Employee>> GetEmployeesAsync()
    {
        try
        {
            return await _httpClient.GetFromJsonAsync<List<Employee>>("employees")
                   ?? new List<Employee>();
        }
        catch
        {
            return new List<Employee>();
        }
    }

    // NEW METHOD
    public async Task<Employee?> GetEmployeeByIdAsync(int id)
    {
        try
        {
            return await _httpClient
                .GetFromJsonAsync<Employee>($"employees/{id}");
        }
        catch
        {
            return null;
        }
    }

    // Create Employee
    public async Task<Employee?> CreateEmployeeAsync(Employee employee)
    {
        try
        {
            using var formData = new MultipartFormDataContent();

            formData.Add(new StringContent(employee.FirstName), "FirstName");
            formData.Add(new StringContent(employee.LastName), "LastName");
            formData.Add(new StringContent(employee.Email ?? ""), "Email");
            formData.Add(new StringContent(employee.HireDate.ToString("yyyy-MM-dd")), "HireDate");
            formData.Add(new StringContent(employee.Salary?.ToString() ?? "0"), "Salary");

            if (employee.EmployeeImage != null)
            {
                var streamContent = new StreamContent(employee.EmployeeImage.OpenReadStream());

                streamContent.Headers.ContentType =
                    new System.Net.Http.Headers.MediaTypeHeaderValue(employee.EmployeeImage.ContentType);

                formData.Add(
                    streamContent,
                    "EmployeeImage",
                    employee.EmployeeImage.FileName);
            }

            var response = await _httpClient.PostAsync("employees", formData);

            // Read response content
            var responseContent = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
            {
                throw new Exception(
                    $"API Error\n" +
                    $"Status Code : {(int)response.StatusCode} ({response.StatusCode})\n\n" +
                    $"Response : {responseContent}");
            }

            return await response.Content.ReadFromJsonAsync<Employee>();
        }
        catch (Exception ex)
        {
            // Show the real error
            throw new Exception("EmployeeService Error: " + ex.Message);
        }
    }

    // UPDATE Employee
    public async Task<Employee?> UpdateEmployeeAsync(Employee employee)
    {
        try
        {
            using var formData = new MultipartFormDataContent();

            formData.Add(new StringContent(employee.EmployeeId.ToString()), "EmployeeID");
            formData.Add(new StringContent(employee.FirstName), "FirstName");
            formData.Add(new StringContent(employee.LastName), "LastName");
            formData.Add(new StringContent(employee.Email ?? ""), "Email");
            formData.Add(new StringContent(employee.HireDate.ToString("yyyy-MM-dd")), "HireDate");
            formData.Add(new StringContent(employee.Salary?.ToString() ?? "0"), "Salary");

            // Upload new image (if selected)
            if (employee.EmployeeImage != null)
            {
                var streamContent = new StreamContent(employee.EmployeeImage.OpenReadStream());

                streamContent.Headers.ContentType =
                    new System.Net.Http.Headers.MediaTypeHeaderValue(employee.EmployeeImage.ContentType);

                formData.Add(
                    streamContent,
                    "EmployeeImage",
                    employee.EmployeeImage.FileName);
            }

            var response = await _httpClient.PutAsync(
                $"employees/{employee.EmployeeId}",
                formData);

            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadFromJsonAsync<Employee>();
            }

            return null;
        }
        catch
        {
            return null;
        }
    }

    // Delete Employee

    public class ApiResponse
    {
        public string? Message { get; set; }
    }

    public async Task<string?> DeleteEmployeeAsync(int employeeId)
    {
        try
        {
            var response = await _httpClient.DeleteAsync($"employees/{employeeId}");

            if (!response.IsSuccessStatusCode)
                return null;

            var result = await response.Content.ReadFromJsonAsync<ApiResponse>();

            return result?.Message;
        }
        catch
        {
            return null;
        }
    }

}