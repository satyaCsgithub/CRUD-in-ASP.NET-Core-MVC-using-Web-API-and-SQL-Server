using Microsoft.AspNetCore.Mvc;

public class EmployeeController : Controller
{
    private readonly EmployeeService _service;

    public EmployeeController(EmployeeService service)
    {
        _service = service;
    }

    // SHOW ALL RECORDS
    public async Task<IActionResult> Index()
    {
        var employees = await _service.GetEmployeesAsync();
        return View(employees);
    }

    // SEARCH BY ID
    [HttpGet]
    public async Task<IActionResult> Search(int id)
    {
        var employee = await _service.GetEmployeeByIdAsync(id);

        if (employee == null)
        {
            ViewBag.Message = $"Employee with ID {id} not found";

            return View(
                "Index",
                new List<Employee>()
            );
        }

        return View(
            "Index",
            new List<Employee> { employee }
        );
    }

    [HttpGet]
    public async Task<IActionResult> SearchMult(
        int? id,
        string? firstName,
        string? lastName)
    {
        var employees = await _service.GetEmployeesAsync();

        if (id.HasValue)
        {
            employees = employees
                .Where(e => e.EmployeeId == id.Value)
                .ToList();
        }

        if (!string.IsNullOrWhiteSpace(firstName))
        {
            employees = employees
                .Where(e =>
                    e.FirstName != null &&
                    e.FirstName.Contains(
                        firstName,
                        StringComparison.OrdinalIgnoreCase))
                .ToList();
        }

        if (!string.IsNullOrWhiteSpace(lastName))
        {
            employees = employees
                .Where(e =>
                    e.LastName != null &&
                    e.LastName.Contains(
                        lastName,
                        StringComparison.OrdinalIgnoreCase))
                .ToList();
        }

        if (!employees.Any())
        {
            ViewBag.Message = "No employee found";
        }

        return View("SearchMult", employees);
    }

    // POST: Employee/Create
    // Show form
    [HttpGet]
    public IActionResult Create()
    {
        return View();
    }

    [HttpPost]
    public async Task<IActionResult> Create(Employee employee, IFormFile? EmployeeImage)
    {
        if (EmployeeImage == null || EmployeeImage.Length == 0)
        {
            ModelState.AddModelError("EmployeeImage", "Employee Image is required.");
        }

        if (!ModelState.IsValid)
        {
            return View(employee);
        }

        employee.EmployeeImage = EmployeeImage;

        employee.CreatedAt = DateTime.Now;
        employee.UpdatedAt = DateTime.Now;

        var result = await _service.CreateEmployeeAsync(employee);

        if (result == null)
        {
            TempData["ErrorMessage"] = "Employee creation failed.";
            return View(employee);
        }

        TempData["SuccessMessage"] = "Employee created successfully!";
        return RedirectToAction("SearchMult");
    }


    // GET: Employee/Update/14
    [HttpGet]
    public async Task<IActionResult> Update(int id)
    {
        var employee = await _service.GetEmployeeByIdAsync(id);

        if (employee == null)
        {
            TempData["ErrorMessage"] = "Employee not found.";
            return RedirectToAction("SearchMult");
        }

        return View(employee);
    }


    // POST: Employee/Update
    [HttpPost]
    public async Task<IActionResult> Update(
    Employee employee,
    IFormFile? EmployeeImage)
    {
        if (!ModelState.IsValid)
        {
            return View(employee);
        }

        // Assign uploaded image to model
        employee.EmployeeImage = EmployeeImage;

        employee.UpdatedAt = DateTime.Now;

        var updatedEmployee = await _service.UpdateEmployeeAsync(employee);

        if (updatedEmployee == null)
        {
            TempData["ErrorMessage"] = "Employee update failed. Please try again.";
            return View(employee);
        }

        TempData["SuccessMessage"] = "Employee updated successfully!";
        return RedirectToAction("SearchMult");
    }

    // GET: Employee/Delete/14
    [HttpGet]
    public async Task<IActionResult> Delete(int id)
    {
        var employee = await _service.GetEmployeeByIdAsync(id);

        if (employee == null)
        {
            TempData["DelErrorMessage"] = "Employee not found. Please check service running or not!";
            return RedirectToAction("SearchMult");
        }

        return View(employee); // confirmation view
    }


    // POST: Employee/Delete
    [HttpPost, ActionName("Delete")]
    public async Task<IActionResult> DeleteConfirmed(int id, string firstName, string lastName)
    {
        var resultMessage = await _service.DeleteEmployeeAsync(id);

        if (resultMessage == null)
        {
            TempData["DelErrorMessage"] =
        $"Employee with ID {id} ({firstName} {lastName}) delete failed. Please try again.";
            return RedirectToAction("SearchMult");
        }

        TempData["DelSuccessMessage"] =
            resultMessage.Replace(
                " deleted successfully.",
                $" ({firstName} {lastName}) deleted successfully.");

        return RedirectToAction("SearchMult");
    }

}