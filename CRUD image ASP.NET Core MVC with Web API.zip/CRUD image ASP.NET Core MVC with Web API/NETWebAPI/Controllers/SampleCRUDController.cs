using Microsoft.AspNetCore.Mvc;

namespace NETWebAPI.Controllers;

[ApiController]
[Route("api/[controller]")]
public class SampleCRUDController : ControllerBase
{
    static List<string> strings = new()
    {
        "Satyaprakash", "Sachin", "Mahesh", "Kapil"
    };

    // GET: api/SampleCRUD
    [HttpGet]
    public ActionResult<IEnumerable<string>> Get()
    {
        return Ok(strings);
    }

    // GET: api/SampleCRUD/2
    [HttpGet("{id}")]
    public ActionResult<string> Get(int id)
    {
        if (id < 0 || id >= strings.Count)
            return NotFound("Invalid ID");

        return Ok(strings[id]);
    }

    // POST: api/SampleCRUD
    [HttpPost]
    public ActionResult Post([FromBody] string value)
    {
        strings.Add(value);
        return Ok(strings);
    }

    // PUT: api/SampleCRUD/2
    [HttpPut("{id}")]
    public ActionResult Put(int id, [FromBody] string value)
    {
        if (id < 0 || id >= strings.Count)
            return NotFound("Invalid ID");

        strings[id] = value;
        return Ok(strings);
    }

    // DELETE: api/SampleCRUD/2
    [HttpDelete("{id}")]
    public ActionResult Delete(int id)
    {
        if (id < 0 || id >= strings.Count)
            return NotFound("Invalid ID");

        strings.RemoveAt(id);
        return Ok(strings);
    }
}
