﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace NETWebAPP.Pages;

public class PrivacyModel : PageModel
{
    public void OnGet()
    {
    }
}

