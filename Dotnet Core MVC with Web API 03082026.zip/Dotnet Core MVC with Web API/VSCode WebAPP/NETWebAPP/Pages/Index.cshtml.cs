using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace NETWebAPP.Pages;

public class IndexModel : PageModel
{
    public void OnGet()
    {

    }
}
