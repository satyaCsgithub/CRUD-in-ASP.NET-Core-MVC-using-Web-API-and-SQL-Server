using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;

public class EmployeeService
{
    private readonly HttpClient _httpClient;

    public EmployeeService(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    // =========================================================
    // BASIC AUTHENTICATION
    // =========================================================
    private void AddBasicAuthentication()
    {
        var username = "admin123";
        var password = "admin@12345";

        var credentials = Convert.ToBase64String(
            Encoding.UTF8.GetBytes($"{username}:{password}")
        );

        _httpClient.DefaultRequestHeaders.Authorization =
            new AuthenticationHeaderValue("Basic", credentials);
    }


    // =========================================================
    // GET ALL EMPLOYEES
    // =========================================================
    public async Task<List<Employee>> GetEmployeesAsync()
    {
        try
        {
            AddBasicAuthentication();

            return await _httpClient
                .GetFromJsonAsync<List<Employee>>("employees")
                ?? new List<Employee>();
        }
        catch
        {
            return new List<Employee>();
        }
    }


    // =========================================================
    // GET EMPLOYEE BY ID
    // =========================================================
    public async Task<Employee?> GetEmployeeByIdAsync(int id)
    {
        try
        {
            AddBasicAuthentication();

            return await _httpClient
                .GetFromJsonAsync<Employee>($"employees/{id}");
        }
        catch
        {
            return null;
        }
    }


    // =========================================================
    // CREATE EMPLOYEE
    // =========================================================
    public async Task<Employee?> CreateEmployeeAsync(Employee employee)
    {
        try
        {
            AddBasicAuthentication();

            using var formData = new MultipartFormDataContent();

            formData.Add(
                new StringContent(employee.FirstName),
                "FirstName");

            formData.Add(
                new StringContent(employee.LastName),
                "LastName");

            formData.Add(
                new StringContent(employee.Email ?? ""),
                "Email");

            formData.Add(
                new StringContent(employee.HireDate.ToString("yyyy-MM-dd")),
                "HireDate");

            formData.Add(
                new StringContent(employee.Salary?.ToString() ?? "0"),
                "Salary");

            if (employee.EmployeeImage != null)
            {
                var streamContent = new StreamContent(
                    employee.EmployeeImage.OpenReadStream());

                streamContent.Headers.ContentType =
                    new MediaTypeHeaderValue(
                        employee.EmployeeImage.ContentType);

                formData.Add(
                    streamContent,
                    "EmployeeImage",
                    employee.EmployeeImage.FileName);
            }

            var response = await _httpClient.PostAsync(
                "employees",
                formData);

            var responseContent =
                await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
            {
                throw new Exception(
                    $"API Error\n" +
                    $"Status Code : {(int)response.StatusCode} ({response.StatusCode})\n\n" +
                    $"Response : {responseContent}");
            }

            return await response.Content
                .ReadFromJsonAsync<Employee>();
        }
        catch (Exception ex)
        {
            throw new Exception(
                "EmployeeService Error: " + ex.Message);
        }
    }


    // =========================================================
    // UPDATE EMPLOYEE
    // =========================================================
    public async Task<Employee?> UpdateEmployeeAsync(Employee employee)
    {
        try
        {
            AddBasicAuthentication();

            using var formData = new MultipartFormDataContent();

            formData.Add(
                new StringContent(employee.EmployeeId.ToString()),
                "EmployeeID");

            formData.Add(
                new StringContent(employee.FirstName),
                "FirstName");

            formData.Add(
                new StringContent(employee.LastName),
                "LastName");

            formData.Add(
                new StringContent(employee.Email ?? ""),
                "Email");

            formData.Add(
                new StringContent(employee.HireDate.ToString("yyyy-MM-dd")),
                "HireDate");

            formData.Add(
                new StringContent(employee.Salary?.ToString() ?? "0"),
                "Salary");

            if (employee.EmployeeImage != null)
            {
                var streamContent = new StreamContent(
                    employee.EmployeeImage.OpenReadStream());

                streamContent.Headers.ContentType =
                    new MediaTypeHeaderValue(
                        employee.EmployeeImage.ContentType);

                formData.Add(
                    streamContent,
                    "EmployeeImage",
                    employee.EmployeeImage.FileName);
            }

            var response = await _httpClient.PutAsync(
                $"employees/{employee.EmployeeId}",
                formData);

            if (response.IsSuccessStatusCode)
            {
                return await response.Content
                    .ReadFromJsonAsync<Employee>();
            }

            return null;
        }
        catch
        {
            return null;
        }
    }


    // =========================================================
    // DELETE EMPLOYEE
    // =========================================================
    public class ApiResponse
    {
        public string? Message { get; set; }
    }

    public async Task<string?> DeleteEmployeeAsync(int employeeId)
    {
        try
        {
            AddBasicAuthentication();

            var response = await _httpClient.DeleteAsync(
                $"employees/{employeeId}");

            if (!response.IsSuccessStatusCode)
                return null;

            var result = await response.Content
                .ReadFromJsonAsync<ApiResponse>();

            return result?.Message;
        }
        catch
        {
            return null;
        }
    }
}