// Import ASP.NET Core output formatter base classes
using Microsoft.AspNetCore.Mvc.Formatters;

// Import text encoding utilities (UTF8, Unicode)
using System.Text;

// Import non-generic collection interfaces like IEnumerable
using System.Collections;

// Import reflection utilities to inspect object properties at runtime
using System.Reflection;

// Custom output formatter that formats API responses as plain text
public class PlainTextOutputFormatter : TextOutputFormatter
{
    // Constructor: configure supported media types and encodings
    public PlainTextOutputFormatter()
    {
        // Tell ASP.NET Core this formatter supports "text/plain"
        SupportedMediaTypes.Add("text/plain");

        // Add supported text encodings
        SupportedEncodings.Add(Encoding.UTF8);
        SupportedEncodings.Add(Encoding.Unicode);
    }

    // Determines whether this formatter can write the specified type
    protected override bool CanWriteType(Type? type)
    {
        // Returning true means this formatter supports ALL types
        return true; 
    }

    // Main method that writes the response body
    public override async Task WriteResponseBodyAsync(
        OutputFormatterWriteContext context,
        Encoding selectedEncoding)
    {
        // Get HTTP response object
        var response = context.HttpContext.Response;

        // Get the object returned from the controller
        var obj = context.Object;

        // Variable to hold final formatted result
        string result;

        // Check if object is a collection (but not a string)
        if (obj is IEnumerable enumerable && !(obj is string))
        {
            // Store each formatted line
            var lines = new List<string>();

            // Iterate through each item in the collection
            foreach (var item in enumerable)
            {
                // Handle null items safely
                if (item == null)
                {
                    lines.Add(string.Empty);
                    continue;
                }

                // Use reflection to get all public instance properties
                var props = item.GetType()
                                .GetProperties(BindingFlags.Public | BindingFlags.Instance);

                // Build "PropertyName: Value" pairs
                var propValues = props
                    .Select(p => $"{p.Name}: {p.GetValue(item)}");

                // Combine properties into a single line separated by comma
                lines.Add(string.Join(", ", propValues));
            }

            // Join all lines using newline separator
            result = string.Join(Environment.NewLine, lines);
        }
        else
        {
            // If object is single value, just convert to string
            // If null, return empty string
            result = obj?.ToString() ?? string.Empty;
        }

        // Write final result to HTTP response using selected encoding
        await response.WriteAsync(result, selectedEncoding);
    }
}