// Import ASP.NET Core formatter base classes
using Microsoft.AspNetCore.Mvc.Formatters;

// Import text encoding utilities (UTF8, Unicode)
using System.Text;

// Import non-generic collection interface (IEnumerable)
using System.Collections;

// Import reflection utilities to inspect object properties at runtime
using System.Reflection;

namespace NETWebAPI.Filters
{
    // Custom output formatter that formats API responses as CSV
    public class CsvOutputFormatter : TextOutputFormatter
    {
        // Constructor: configure supported media types and encodings
        public CsvOutputFormatter()
        {
            // Tell ASP.NET Core this formatter supports "text/csv"
            SupportedMediaTypes.Add("text/csv");

            // Add supported encodings
            SupportedEncodings.Add(Encoding.UTF8);
            SupportedEncodings.Add(Encoding.Unicode);
        }

        // Determines whether this formatter can write the specified type
        protected override bool CanWriteType(Type? type)
        {
            // Returning true means this formatter supports ALL types
            return true; 
        }

        // Main method responsible for writing the response body
        public override async Task WriteResponseBodyAsync(
            OutputFormatterWriteContext context,
            Encoding selectedEncoding)
        {
            // Get HTTP response object
            var response = context.HttpContext.Response;

            // Get the object returned from the controller
            var obj = context.Object;

            // StringBuilder improves performance when building large text
            var buffer = new StringBuilder();

            // Check if object is a collection (but not a string)
            if (obj is IEnumerable enumerable && !(obj is string))
            {
                // Track if header row is already written
                bool headerWritten = false;

                // Store property metadata (retrieved once)
                PropertyInfo[]? properties = null;

                // Iterate through each item in collection
                foreach (var item in enumerable)
                {
                    // Skip null items safely
                    if (item == null)
                        continue;

                    // Use reflection to get public instance properties (only once)
                    properties ??= item.GetType()
                                        .GetProperties(BindingFlags.Public | BindingFlags.Instance);

                    // Write CSV header row only once
                    if (!headerWritten)
                    {
                        buffer.AppendLine(string.Join(",",
                            properties.Select(p => Escape(p.Name))));
                        headerWritten = true;
                    }

                    // Extract property values and escape them for CSV safety
                    var values = properties
                        .Select(p => Escape(p.GetValue(item)?.ToString() ?? string.Empty));

                    // Write CSV data row
                    buffer.AppendLine(string.Join(",", values));
                }
            }
            // Handle single object (not a collection)
            else if (obj != null)
            {
                // Get public instance properties using reflection
                var properties = obj.GetType()
                    .GetProperties(BindingFlags.Public | BindingFlags.Instance);

                // Write header row (property names)
                buffer.AppendLine(string.Join(",",
                    properties.Select(p => Escape(p.Name))));

                // Extract and escape property values
                var values = properties
                    .Select(p => Escape(p.GetValue(obj)?.ToString() ?? string.Empty));

                // Write single CSV row
                buffer.AppendLine(string.Join(",", values));
            }

            // Write the final CSV content to HTTP response
            await response.WriteAsync(buffer.ToString(), selectedEncoding);
        }

        // Helper method to properly escape CSV values
        private string Escape(string value)
        {
            // Return empty string if value is null or empty
            if (string.IsNullOrEmpty(value))
                return string.Empty;

            // If value contains comma, quote, or newline → wrap in quotes
            if (value.Contains(",") || value.Contains("\"") || value.Contains("\n"))
            {
                // Escape double quotes by doubling them
                value = value.Replace("\"", "\"\"");

                // Wrap entire value in quotes
                return $"\"{value}\"";
            }

            // If no special characters, return value as-is
            return value;
        }
    }
}