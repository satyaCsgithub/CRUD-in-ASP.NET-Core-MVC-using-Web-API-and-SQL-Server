using System.ComponentModel.DataAnnotations;

namespace NETWebAPI.Models
{
    public class User
    {
        [Key]
        public int UserId { get; set; }

        public string UserName { get; set; } = string.Empty;

        public string Password { get; set; } = string.Empty;

        public string? FullName { get; set; }

        public string? Role { get; set; }
    }
}