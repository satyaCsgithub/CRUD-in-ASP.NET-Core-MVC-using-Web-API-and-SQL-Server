using Microsoft.EntityFrameworkCore;
using NETWebAPI.Models;

namespace NETWebAPI.Data
{
    public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options)
        : base(options)
    {
    }

    public DbSet<Employee> Employees => Set<Employee>();

    public DbSet<User> Users { get; set; }
}

}