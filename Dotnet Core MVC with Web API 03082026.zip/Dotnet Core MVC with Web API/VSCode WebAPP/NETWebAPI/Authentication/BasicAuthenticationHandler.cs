using System.Net.Http.Headers;
using System.Security.Claims;
using System.Text;
using System.Text.Encodings.Web;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using NETWebAPI.Data;
using NETWebAPI.Models;

public class BasicAuthenticationHandler
    : AuthenticationHandler<AuthenticationSchemeOptions>
{
    private readonly AppDbContext _context;

    public BasicAuthenticationHandler(
        IOptionsMonitor<AuthenticationSchemeOptions> options,
        ILoggerFactory logger,
        UrlEncoder encoder,
        AppDbContext context)
        : base(options, logger, encoder)
    {
        _context = context;
    }

    protected override async Task<AuthenticateResult> HandleAuthenticateAsync()
    {
        if (!Request.Headers.ContainsKey("Authorization"))
        {
            Context.Items["AuthError"] = "Missing Authorization Header";
            return AuthenticateResult.Fail("Missing Authorization Header");
        }

        try
        {
            // Read Authorization Header
            var authorization = Request.Headers.Authorization.ToString();

            // Parse Authorization Header
            var authHeader = AuthenticationHeaderValue.Parse(authorization);

            // Decode Base64 Credentials
            var credentialBytes = Convert.FromBase64String(authHeader.Parameter!);

            // Extract Username and Password
            var credentials = Encoding.UTF8
                .GetString(credentialBytes)
                .Split(':', 2);

            var username = credentials[0];
            var password = credentials[1];

            // Validate User from SQL Server using Entity Framework Core
            var user = await _context.Users.FirstOrDefaultAsync(u =>
                u.UserName == username &&
                u.Password == password);

            if (user == null)
            {
                Context.Items["AuthError"] = "Invalid Username or Password";
                return AuthenticateResult.Fail("Invalid Username or Password");
            }

            // Create Claims
            var claims = new[]
            {
                new Claim(ClaimTypes.NameIdentifier, user.UserId.ToString()),
                new Claim(ClaimTypes.Name, user.UserName),
                new Claim(ClaimTypes.Role, user.Role ?? "User")
            };

            // Create ClaimsIdentity
            var identity = new ClaimsIdentity(claims, Scheme.Name);

            // Create ClaimsPrincipal
            var principal = new ClaimsPrincipal(identity);

            // Create AuthenticationTicket
            var ticket = new AuthenticationTicket(principal, Scheme.Name);

            return AuthenticateResult.Success(ticket);
        }
        catch
        {
            Context.Items["AuthError"] = "Invalid Authorization Header";
            return AuthenticateResult.Fail("Invalid Authorization Header");
        }
    }

    protected override async Task HandleChallengeAsync(AuthenticationProperties properties)
    {
        Response.StatusCode = StatusCodes.Status401Unauthorized;
        Response.ContentType = "application/json";

        var message = Context.Items["AuthError"]?.ToString() ?? "Unauthorized";

        await Response.WriteAsJsonAsync(new
        {
            Status = 401,
            Message = message
        });
    }
}