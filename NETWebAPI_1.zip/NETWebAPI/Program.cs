using OpenTelemetry.Resources;
using OpenTelemetry.Trace;
using System.Diagnostics;
using Microsoft.Extensions.Caching.Hybrid;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Asp.Versioning;
using System.Reflection;
using Microsoft.EntityFrameworkCore;
using NETWebAPI.Data;
using NETWebAPI.Filters;
using Microsoft.AspNetCore.Authentication;
using Microsoft.OpenApi;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

//builder.Services.AddControllers();

//Apply Content Negotiation

// builder.Services.AddControllers(options => 
// { 
//     options.RespectBrowserAcceptHeader = true;
// }).AddXmlSerializerFormatters();

// builder.Services.AddControllers(options => 
// { 
//     options.RespectBrowserAcceptHeader = true;
//     options.ReturnHttpNotAcceptable = true;
// }).AddXmlSerializerFormatters();

// builder.Services.AddControllers(options =>
// {
//     options.RespectBrowserAcceptHeader = true;
//     options.ReturnHttpNotAcceptable = true;
//     options.OutputFormatters.Add(new PlainTextOutputFormatter());
// })
// .AddXmlSerializerFormatters();

builder.Services.AddControllers(options =>
{
    options.RespectBrowserAcceptHeader = true;
    options.ReturnHttpNotAcceptable = true;
    options.OutputFormatters.Add(new PlainTextOutputFormatter());
    options.OutputFormatters.Add(new CsvOutputFormatter());
}).AddXmlSerializerFormatters();

//Apply Content Negotiation

// Learn more about configuring OpenAPI at https://aka.ms/aspnet/openapi
builder.Services.AddOpenApi();

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    var xmlFilename =
        $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";

    options.IncludeXmlComments(
        Path.Combine(AppContext.BaseDirectory, xmlFilename));

    // options.AddSecurityDefinition("BasicAuth",
    //     new OpenApiSecurityScheme
    //     {
    //         Type = SecuritySchemeType.Http,
    //         Scheme = "basic",
    //         In = ParameterLocation.Header,
    //         Description = "Enter Username and Password"
    //     });

    options.AddSecurityDefinition("Bearer",
    new OpenApiSecurityScheme
    {
        Type = SecuritySchemeType.Http,
        Scheme = "bearer",
        BearerFormat = "JWT",
        In = ParameterLocation.Header,
        Description = "Enter JWT token"
    });

    // options.AddSecurityRequirement(document =>
    //     new OpenApiSecurityRequirement
    //     {
    //         [new OpenApiSecuritySchemeReference(
    //             "BasicAuth",
    //             document)] = new List<string>()
    //     });

    options.AddSecurityRequirement(document =>
    new OpenApiSecurityRequirement
    {
        [new OpenApiSecuritySchemeReference(
            "Bearer",
            document)] = new List<string>()
    });

    // API VERSIONING
    options.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "My API",
        Version = "v1"
    });

    options.SwaggerDoc("v2", new OpenApiInfo
    {
        Title = "My API",
        Version = "v2"
    });

    options.DocInclusionPredicate((docName, apiDesc) =>
    {
        return apiDesc.GroupName == docName;
    });
});
//Basic Authentication Swagger code is here

builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(
        builder.Configuration.GetConnectionString("DefaultConnection")
        //,sqlOptions => sqlOptions.CommandTimeout(1)
    )
);

//Define a named policy
builder.Services.AddCors(Options =>
{
    Options.AddPolicy("AllowFrontEnd", policy =>
    {
        policy.WithOrigins("https://myapp.com", "http://localhost:5028")
              .WithMethods("GET", "POST", "PUT", "DELETE")
              .WithHeaders("Content-Type", "application/json");
    });
});

// builder.Services.AddCors(options =>{
//     options.AddPolicy("AllowFrontEnd", policy =>
//     {
//         policy.WithOrigins("http://localhost:5028")
//               .AllowAnyMethod()
//               .AllowAnyHeader();
//     });
// });

//Replace your current Basic Authentication registration with JWT
// builder.Services
// .AddAuthentication("BasicAuthentication")
// .AddScheme<AuthenticationSchemeOptions,
// BasicAuthenticationHandler>("BasicAuthentication", null);
// builder.Services.AddAuthorization();

//JWT Authentication

builder.Services
    .AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters =
            new TokenValidationParameters
            {
                ValidateIssuer = true,
                ValidateAudience = true,
                ValidateLifetime = true,
                ValidateIssuerSigningKey = true,

                ValidIssuer =
                    builder.Configuration["Jwt:Issuer"],

                ValidAudience =
                    builder.Configuration["Jwt:Audience"],

                IssuerSigningKey =
                    new SymmetricSecurityKey(
                        Encoding.UTF8.GetBytes(
                            builder.Configuration["Jwt:Key"]!))
            };
    });

builder.Services.AddAuthorization();

//JWT Authentication

//Rate limit
builder.Services.AddRateLimiter(options =>
{
    options.AddFixedWindowLimiter("fixed", limiter =>
    {
        limiter.PermitLimit = 5;
        limiter.Window = TimeSpan.FromSeconds(30);
        limiter.QueueLimit = 0;
    });

    options.OnRejected = async (context, cancellationToken) =>
    {
        context.HttpContext.Response.StatusCode = 429;
        context.HttpContext.Response.ContentType = "application/json";

        await context.HttpContext.Response.WriteAsJsonAsync(
            new
            {
                success = false,
                message = "Rate limit exceeded. Please wait 30 seconds before trying again."
            },
            cancellationToken);
    };
});
//Rate limit

//Output Caching
builder.Services.AddOutputCache(options =>
{
    options.AddPolicy("ApiCache", policy =>
    {
        policy.Expire(TimeSpan.FromSeconds(30));
    });
});
//Output Caching

builder.Services.AddExceptionHandler<GlobalExceptionHandler>();
builder.Services.AddProblemDetails();
//ApiVersion
builder.Services
    .AddApiVersioning(options =>
    {
        options.DefaultApiVersion = new ApiVersion(1, 0);
        options.AssumeDefaultVersionWhenUnspecified = true;
        options.ReportApiVersions = true;

        options.ApiVersionReader =
            new UrlSegmentApiVersionReader();
    })
    .AddMvc()
    .AddApiExplorer(options =>
    {
        options.GroupNameFormat = "'v'VVV";
        options.SubstituteApiVersionInUrl = true;
    });
//ApiVersion

// Health Checks

// Health Checks
var connectionString =
    builder.Configuration.GetConnectionString("DefaultConnection")
    ?? throw new InvalidOperationException(
        "Connection string 'DefaultConnection' was not found.");

builder.Services
    .AddHealthChecks()
    .AddCheck(
        "api",
        () => Microsoft.Extensions.Diagnostics.HealthChecks.HealthCheckResult.Healthy(
            "API is running"),
        tags: new[] { "live" })
    .AddSqlServer(
        connectionString,
        tags: new[] { "ready" });

// Health Checks

// Register HybridCache
builder.Services.AddHybridCache(options =>
{
    options.DefaultEntryOptions = new HybridCacheEntryOptions
    {
        Expiration = TimeSpan.FromMinutes(5),
        LocalCacheExpiration = TimeSpan.FromMinutes(2)
    };
});
// Register HybridCache


 //OpenTelemetry registration

builder.Services.AddOpenTelemetry()
    .ConfigureResource(resource =>
        resource.AddService("EmployeeWebAPI"))
    .WithTracing(tracing => tracing
        .AddAspNetCoreInstrumentation(options =>
        {
            options.EnrichWithHttpRequest = (activity, request) =>
            {
                activity.SetTag(
                    "client.user_agent",
                    request.Headers.UserAgent.ToString());

                activity.SetTag(
                    "client.referer",
                    request.Headers.Referer.ToString());
            };

            // Feature 2: Exception tracing
            options.RecordException = true;

            options.EnrichWithException = (activity, exception) =>
            {
                activity.SetTag(
                    "exception.type",
                    exception.GetType().FullName);

                activity.SetTag(
                    "exception.message",
                    exception.Message);
            };
        })
        .AddProcessor(new HttpTraceProcessor())
        .AddConsoleExporter());

//OpenTelemetry registration

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();

    app.UseSwagger();
    app.UseSwaggerUI(c =>
{
    c.SwaggerEndpoint(
        "/swagger/v1/swagger.json",
        "My API V1");

    c.SwaggerEndpoint(
        "/swagger/v2/swagger.json",
        "My API V2");
});
}

app.UseExceptionHandler();
app.UseHttpsRedirection();
//Must be placed before UseAuthorization
app.UseCors("AllowFrontEnd");
app.UseStaticFiles();
app.UseAuthentication();
app.UseAuthorization();
app.UseRateLimiter();
app.UseOutputCache();
//app.UseMiddleware<CustomCacheMiddleware>();

//API Health Check

// 1. API Liveness Check
app.MapGet("/health/live", () => Results.Ok(new
{
    status = "Healthy",
    message = "API is running"
}))
.WithName("HealthLive")
.WithTags("Health")
.AllowAnonymous();

// 2. Database Readiness Check
app.MapGet("/health/ready", async (
    HealthCheckService healthCheckService) =>
{
    var report = await healthCheckService.CheckHealthAsync(
        check => check.Tags.Contains("ready"));

    var statusCode = report.Status == HealthStatus.Healthy
        ? StatusCodes.Status200OK
        : StatusCodes.Status503ServiceUnavailable;

    return Results.Json(new
    {
        status = report.Status.ToString(),
        checks = report.Entries.ToDictionary(
            entry => entry.Key,
            entry => entry.Value.Status.ToString())
    }, statusCode: statusCode);
})
.WithName("HealthReady")
.WithTags("Health")
.AllowAnonymous();

// 3. Complete Health Check
app.MapGet("/health", async (
    HealthCheckService healthCheckService) =>
{
    var report = await healthCheckService.CheckHealthAsync();

    var statusCode = report.Status == HealthStatus.Healthy
        ? StatusCodes.Status200OK
        : StatusCodes.Status503ServiceUnavailable;

    return Results.Json(new
    {
        status = report.Status.ToString(),
        checks = report.Entries.ToDictionary(
            entry => entry.Key,
            entry => entry.Value.Status.ToString())
    }, statusCode: statusCode);
})
.WithName("Health")
.WithTags("Health")
.AllowAnonymous();

//API Health Check

app.MapControllers();
app.Run();