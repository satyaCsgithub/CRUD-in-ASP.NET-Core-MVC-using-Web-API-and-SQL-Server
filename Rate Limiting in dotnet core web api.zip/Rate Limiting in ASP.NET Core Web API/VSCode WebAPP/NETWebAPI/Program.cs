using System.Reflection;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using NETWebAPI.Data;
using NETWebAPI.Filters;
using Microsoft.AspNetCore.Authentication;
using Microsoft.OpenApi;
using Microsoft.AspNetCore.RateLimiting;
using System.Threading.RateLimiting;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

//builder.Services.AddControllers();

//Apply Content Negotiation

// builder.Services.AddControllers(options => 
// { 
//     options.RespectBrowserAcceptHeader = true;
// }).AddXmlSerializerFormatters();

// builder.Services.AddControllers(options => 
// { 
//     options.RespectBrowserAcceptHeader = true;
//     options.ReturnHttpNotAcceptable = true;
// }).AddXmlSerializerFormatters();

// builder.Services.AddControllers(options =>
// {
//     options.RespectBrowserAcceptHeader = true;
//     options.ReturnHttpNotAcceptable = true;
//     options.OutputFormatters.Add(new PlainTextOutputFormatter());
// })
// .AddXmlSerializerFormatters();

builder.Services.AddControllers(options => 
{
    options.RespectBrowserAcceptHeader = true;
    options.ReturnHttpNotAcceptable = true;
    options.OutputFormatters.Add(new PlainTextOutputFormatter());
    options.OutputFormatters.Add(new CsvOutputFormatter());
}).AddXmlSerializerFormatters();

//Apply Content Negotiation

// Learn more about configuring OpenAPI at https://aka.ms/aspnet/openapi
builder.Services.AddOpenApi();

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    // using System.Reflection;
var xmlFilename = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
options.IncludeXmlComments(Path.Combine(AppContext.BaseDirectory, xmlFilename));

//Basic Authentication Swagger code is here
options.AddSecurityDefinition("BasicAuth",
    new OpenApiSecurityScheme
    {
        Type = SecuritySchemeType.Http,
        Scheme = "basic",
        In = ParameterLocation.Header,
        Description = "Enter Username and Password"
    });

options.AddSecurityRequirement(document =>
    new OpenApiSecurityRequirement
    {
        [new OpenApiSecuritySchemeReference(
            "BasicAuth",
            document)] = new List<string>()
    });

});
//Basic Authentication Swagger code is here

builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(
        builder.Configuration.GetConnectionString("DefaultConnection")
    )
);

//Define a named policy
builder.Services.AddCors(Options =>{
    Options.AddPolicy("AllowFrontEnd", policy =>
    {
        policy.WithOrigins("https://myapp.com", "http://localhost:5028")
              .WithMethods ("GET", "POST","PUT","DELETE")
              .WithHeaders ("Content-Type", "application/json");
    });
});

// builder.Services.AddCors(options =>{
//     options.AddPolicy("AllowFrontEnd", policy =>
//     {
//         policy.WithOrigins("http://localhost:5028")
//               .AllowAnyMethod()
//               .AllowAnyHeader();
//     });
// });

builder.Services
.AddAuthentication("BasicAuthentication")
.AddScheme<AuthenticationSchemeOptions,
BasicAuthenticationHandler>("BasicAuthentication", null);
builder.Services.AddAuthorization();

//Rate limit
builder.Services.AddRateLimiter(options =>
{
    options.AddFixedWindowLimiter("fixed", limiter =>
    {
        limiter.PermitLimit = 5;
        limiter.Window = TimeSpan.FromSeconds(30);
        limiter.QueueLimit = 0;
    });

    options.OnRejected = async (context, cancellationToken) =>
    {
        context.HttpContext.Response.StatusCode = 429;
        context.HttpContext.Response.ContentType = "application/json";

        await context.HttpContext.Response.WriteAsJsonAsync(
            new
            {
                success = false,
                message = "Rate limit exceeded. Please wait 30 seconds before trying again."
            },
            cancellationToken);
    };
});
//Rate limit

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();

    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        c.SwaggerEndpoint("/swagger/v1/swagger.json", "My API V1");
    });
}

app.UseHttpsRedirection();

//Must be placed before UseAuthorization
app.UseCors("AllowFrontEnd");

app.UseStaticFiles();

app.UseHttpsRedirection();

app.UseAuthentication();
app.UseAuthorization();
app.UseRateLimiter();
app.MapControllers();

app.UseExceptionHandler("/error");

app.Run();
