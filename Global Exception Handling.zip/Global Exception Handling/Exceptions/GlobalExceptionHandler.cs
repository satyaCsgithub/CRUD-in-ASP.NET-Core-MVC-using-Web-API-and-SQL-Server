using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;

public class GlobalExceptionHandler : IExceptionHandler
{
    private readonly ILogger<GlobalExceptionHandler> _logger;

    public GlobalExceptionHandler(
        ILogger<GlobalExceptionHandler> logger)
    {
        _logger = logger;
    }

    public async ValueTask<bool> TryHandleAsync(
        HttpContext httpContext,
        Exception exception,
        CancellationToken cancellationToken)
    {
        // Log the actual exception
        _logger.LogError(
            exception,
            "An unexpected error occurred.");

        var statusCode = StatusCodes.Status500InternalServerError;
        var message = "An unexpected error occurred.";

        // SQL Server/database connection error
        if (exception is SqlException ||
            exception.InnerException is SqlException)
        {
            statusCode = StatusCodes.Status503ServiceUnavailable;
            message = "Database service is currently unavailable.";
        }

        var problemDetails = new ProblemDetails
        {
            Status = statusCode,
            Title = "Service is Unavailable",
            Detail = message,
            Instance = httpContext.Request.Path
        };

        httpContext.Response.StatusCode = statusCode;

        await httpContext.Response.WriteAsJsonAsync(
            problemDetails,
            cancellationToken);

        return true;
    }
}