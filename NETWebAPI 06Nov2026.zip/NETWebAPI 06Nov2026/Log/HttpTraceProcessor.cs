
using System;
using System.Diagnostics;
using System.IO;
using Microsoft.AspNetCore.WebUtilities;
using OpenTelemetry;
using Microsoft.AspNetCore.Http;
using System.Linq;

public class HttpTraceProcessor : BaseProcessor<Activity>
{
    private static readonly object FileLock = new();

    private readonly string _filePath =
        $@"C:\VSCode WebAPP\OpenTelemetryLogs\HttpTrace_{DateTime.Now:yyyy-MM-dd}.txt";

    public void WriteMetrics(string method, int statusCode, double durationMs)
    {
        string metricsLog =
            $"Date/Time       : {DateTime.Now:yyyy-MM-dd HH:mm:ss}{Environment.NewLine}" +
            $"Metric Type     : HTTP Request Metrics{Environment.NewLine}" +
            $"HTTP Method     : {method}{Environment.NewLine}" +
            $"Status Code     : {statusCode}{Environment.NewLine}" +
            $"Duration        : {durationMs:F2} ms{Environment.NewLine}" +
            "----------------------------------------" +
            Environment.NewLine + Environment.NewLine;

        try
        {
            lock (FileLock)
            {
                Directory.CreateDirectory(
                    Path.GetDirectoryName(_filePath)!);

                File.AppendAllText(_filePath, metricsLog);
            }
        }
        catch (IOException ex)
        {
            Console.WriteLine($"Metrics log write failed: {ex.Message}");
        }
        catch (UnauthorizedAccessException ex)
        {
            Console.WriteLine($"Metrics log access denied: {ex.Message}");
        }
    }

    public override void OnEnd(Activity activity)
    {
        // Feature 3: SQL Server tracing
        if (activity.Kind == ActivityKind.Client)
        {
            string database = activity.GetTagItem("db.name")?.ToString()
                              ?? activity.GetTagItem("db.namespace")?.ToString()
                              ?? "Unknown";

            string sqlStatement =
                activity.GetTagItem("db.statement")?.ToString()
                ?? "SQL statement not available";

            string sqlOperation = System.Text.RegularExpressions.Regex
                .Match(
                    sqlStatement,
                    @"\b(SELECT|INSERT|UPDATE|DELETE)\b",
                    System.Text.RegularExpressions.RegexOptions.IgnoreCase)
                .Value
                .ToUpperInvariant();

            if (string.IsNullOrEmpty(sqlOperation))
                sqlOperation = "OTHER";

            string sqlLog =
                $"Date/Time       : {DateTime.Now:yyyy-MM-dd HH:mm:ss}{Environment.NewLine}" +
                //$"Activity        : {activity.DisplayName}{Environment.NewLine}" +
                //$"SQL Operation   : {sqlStatement.TrimStart().Split(' ')[0]}{Environment.NewLine}" +
                $"SQL Operation   : {sqlOperation}{Environment.NewLine}" +
                $"Database        : {database}{Environment.NewLine}" +
                $"SQL Statement   : {sqlStatement}{Environment.NewLine}" +
                $"Duration        : {activity.Duration.TotalMilliseconds:F2} ms{Environment.NewLine}" +
                //$"Status        : {activity.Status}{Environment.NewLine}" +
                $"Status          : {(activity.Status == ActivityStatusCode.Error ? "Error" : "Success")}{Environment.NewLine}" +
                "----------------------------------------" +
                Environment.NewLine + Environment.NewLine;

            try
            {
                lock (FileLock)
                {
                    Directory.CreateDirectory(
                        Path.GetDirectoryName(_filePath)!);

                    File.AppendAllText(_filePath, sqlLog);
                }
            }
            catch (IOException ex)
            {
                Console.WriteLine($"SQL trace file write failed: {ex.Message}");
            }
            catch (UnauthorizedAccessException ex)
            {
                Console.WriteLine($"SQL trace file access denied: {ex.Message}");
            }

            return;
        }

        // Existing HTTP tracing
        if (activity.Kind != ActivityKind.Server)
            return;

        var statusValue =
            activity.GetTagItem("http.response.status_code");

        if (statusValue == null)
            return;

        int statusCode = Convert.ToInt32(statusValue);

        string endpoint =
     activity.GetTagItem("url.path")?.ToString()
     + activity.GetTagItem("url.query")?.ToString()
     ?? activity.GetTagItem("http.target")?.ToString()
     ?? activity.GetTagItem("http.route")?.ToString()
     ?? activity.DisplayName;

        string method =
            activity.GetTagItem("http.request.method")?.ToString()
            ?? activity.GetTagItem("http.method")?.ToString()
            ?? "HTTP";

        string statusMessage =
            ReasonPhrases.GetReasonPhrase(statusCode);

        string userAgent =
          activity.GetTagItem("user_agent.original")?.ToString()
          ?? activity.GetTagItem("http.user_agent")?.ToString()
          ?? activity.GetTagItem("client.user_agent")?.ToString()
          ?? "Unknown";

        string referer =
            activity.GetTagItem("client.referer")?.ToString()
            ?? "";

        string sourceTool;

        if (userAgent.Contains("Postman", StringComparison.OrdinalIgnoreCase))
        {
            sourceTool = "Postman";
        }
        else if (referer.Contains("swagger", StringComparison.OrdinalIgnoreCase))
        {
            sourceTool = "Swagger UI";
        }
        else if (userAgent.Contains("Chrome/", StringComparison.OrdinalIgnoreCase))
        {
            sourceTool = "Google Chrome";
        }
        else
        {
            sourceTool = "Unknown / Other Client";
        }

        // Skip Swagger and browser resource requests
        if (endpoint.Contains("/swagger", StringComparison.OrdinalIgnoreCase) ||
            endpoint.EndsWith(".js", StringComparison.OrdinalIgnoreCase) ||
            endpoint.EndsWith(".css", StringComparison.OrdinalIgnoreCase) ||
            endpoint.EndsWith(".png", StringComparison.OrdinalIgnoreCase) ||
            endpoint.EndsWith(".ico", StringComparison.OrdinalIgnoreCase))
        {
            return;
        }

        string pcUserName = Environment.UserName;
        string pcName = Environment.MachineName;

        string completeUrl =
            activity.GetTagItem("url.full")?.ToString()
            ?? activity.GetTagItem("http.url")?.ToString()
            ?? (
                activity.GetTagItem("url.scheme")?.ToString() != null &&
                activity.GetTagItem("server.address")?.ToString() != null &&
                activity.GetTagItem("url.path")?.ToString() != null
                    ? $"{activity.GetTagItem("url.scheme")}://{activity.GetTagItem("server.address")}{(activity.GetTagItem("server.port") != null ? ":" + activity.GetTagItem("server.port") : "")}{activity.GetTagItem("url.path")}{activity.GetTagItem("url.query")}"
                    : "Unknown"
            );

        string ipAddress =
            System.Net.NetworkInformation.NetworkInterface
                .GetAllNetworkInterfaces()
                .Where(n => n.OperationalStatus ==
                            System.Net.NetworkInformation.OperationalStatus.Up)
                .SelectMany(n => n.GetIPProperties().UnicastAddresses)
                .Where(a => a.Address.AddressFamily ==
                            System.Net.Sockets.AddressFamily.InterNetwork &&
                            !System.Net.IPAddress.IsLoopback(a.Address))
                .Select(a => a.Address.ToString())
                .FirstOrDefault() ?? "IPv4 not available";


        // Feature 2: Exception tracing
        var exceptionEvent = activity.Events
            .LastOrDefault(e => e.Name == "exception");

        bool hasExceptionEvent = exceptionEvent.Name == "exception";

        string exceptionType =
            activity.GetTagItem("exception.type")?.ToString()
            ?? (hasExceptionEvent
                ? exceptionEvent.Tags
                    .FirstOrDefault(t => t.Key == "exception.type")
                    .Value?.ToString()
                : null)
            ?? "None";

        string exceptionMessage =
            activity.GetTagItem("exception.message")?.ToString()
            ?? (hasExceptionEvent
                ? exceptionEvent.Tags
                    .FirstOrDefault(t => t.Key == "exception.message")
                    .Value?.ToString()
                : null)
            ?? "No exception recorded";

        string logMessage =
            $"Date/Time         : {DateTime.Now:yyyy-MM-dd HH:mm:ss}{Environment.NewLine}" +
            $"Endpoint          : {method} {endpoint}{Environment.NewLine}" +
            $"Complete URL      : {completeUrl}{Environment.NewLine}" +
            $"Status Code       : {statusCode}{Environment.NewLine}" +
            $"Status Message    : {statusMessage}{Environment.NewLine}" +
            $"Duration          : {activity.Duration.TotalMilliseconds:F2} ms{Environment.NewLine}" +
            $"Source Tool       : {sourceTool}{Environment.NewLine}" +
            $"User-Agent        : {userAgent}{Environment.NewLine}" +
            $"PC User Name      : {pcUserName}{Environment.NewLine}" +
            $"PC Name           : {pcName}{Environment.NewLine}" +
            $"IP Address        : {ipAddress}{Environment.NewLine}" +
            $"Exception Type    : {exceptionType}{Environment.NewLine}" +
            $"Exception Message : {exceptionMessage}{Environment.NewLine}" +
            "----------------------------------------" + Environment.NewLine + Environment.NewLine;

        try
        {
            lock (FileLock)
            {
                Directory.CreateDirectory(
                    Path.GetDirectoryName(_filePath)!);

                File.AppendAllText(_filePath, logMessage);
            }
        }
        catch (IOException ex)
        {
            Console.WriteLine($"Trace file write failed: {ex.Message}");
        }
        catch (UnauthorizedAccessException ex)
        {
            Console.WriteLine($"Trace file access denied: {ex.Message}");
        }
    }
}