using System.Text.Json;

public class CustomCacheMiddleware
{
    private readonly RequestDelegate _next;

    private static readonly Dictionary<string, (DateTime Expiry, string Response)> _cache = new();

    public CustomCacheMiddleware(RequestDelegate next)
    {
        _next = next;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        if (context.Request.Path.StartsWithSegments("/api/employees") &&
            context.Request.Method == "GET")
        {
            var cacheKey = context.Request.Path.ToString();

            if (_cache.TryGetValue(cacheKey, out var cached) &&
                cached.Expiry > DateTime.UtcNow)
            {
                context.Response.ContentType = "application/json";

                context.Response.Headers["X-Cache-Status"] =
                    "DATA FETCHED FROM CACHE";

                await context.Response.WriteAsync(cached.Response);

                return;
            }

            var originalBody = context.Response.Body;

            using var memoryStream = new MemoryStream();
            context.Response.Body = memoryStream;

            await _next(context);

            memoryStream.Position = 0;

            var responseBody =
                await new StreamReader(memoryStream).ReadToEndAsync();

            memoryStream.Position = 0;

            context.Response.Body = originalBody;

            _cache[cacheKey] = (
                DateTime.UtcNow.AddSeconds(30),
                responseBody
            );

            context.Response.Headers["X-Cache-Status"] =
                "DATA FETCHED FROM DATABASE";

            await context.Response.WriteAsync(responseBody);

            return;
        }

        await _next(context);
    }
}