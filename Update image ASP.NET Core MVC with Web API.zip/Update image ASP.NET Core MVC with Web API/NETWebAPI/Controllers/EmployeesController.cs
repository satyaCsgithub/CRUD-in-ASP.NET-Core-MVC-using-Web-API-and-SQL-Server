using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using NETWebAPI.Data;
using NETWebAPI.Models;

namespace NETWebAPI.Controllers
{

    [ApiController]
    [Route("api/[controller]")]
    [EnableCors("AllowFrontEnd")] //applied to whole controller
    public class EmployeesController : ControllerBase
    {
        private readonly AppDbContext _context;

        public EmployeesController(AppDbContext context)
        {
            _context = context;
        }

        // GET api/employees
        [HttpGet]
        //[EnableCors("AllowFrontEnd")] //applied to specific http methods
        //[DisableCors]
        public async Task<ActionResult<IEnumerable<Employee>>> GetEmployees()
        {
            return await _context.Employees.ToListAsync();
        }

        // GET api/employees/id
        [HttpGet("{id}")]
        //[DisableCors] //opt-out a specific action
        public async Task<ActionResult<Employee>> GetEmployeeById(int id)
        {
            var employee = await _context.Employees.FindAsync(id);

            if (employee == null)
                return NotFound();

            return employee;
        }

        // POST:
        [HttpPost]
        public async Task<ActionResult<Employee>> CreateEmployee(
    [FromForm] Employee employee,
    IFormFile? EmployeeImage)
        {
            employee.CreatedAt = DateTime.Now;

            if (EmployeeImage != null && EmployeeImage.Length > 0)
            {
                var uploadFolder = Path.Combine(
                    Directory.GetCurrentDirectory(),
                    "wwwroot",
                    "uploads");

                if (!Directory.Exists(uploadFolder))
                {
                    Directory.CreateDirectory(uploadFolder);
                }

                var fileName = Guid.NewGuid().ToString()
                             + Path.GetExtension(EmployeeImage.FileName);

                var filePath = Path.Combine(uploadFolder, fileName);

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await EmployeeImage.CopyToAsync(stream);
                }

                employee.ImagePath = "uploads/" + fileName;
            }
            else
            {
                employee.ImagePath = "uploads/NoImage.jpg";
            }

            _context.Employees.Add(employee);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetEmployees),
                new { id = employee.EmployeeID }, employee);
        }

        // PUT: api/employees/14       

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateEmployee(
    int id,
    [FromForm] Employee employee,
    IFormFile? EmployeeImage)
        {
            if (id != employee.EmployeeID)
            {
                return BadRequest();
            }

            var existingEmployee = await _context.Employees.FindAsync(id);

            if (existingEmployee == null)
            {
                return NotFound();
            }

            // Update employee details
            existingEmployee.FirstName = employee.FirstName;
            existingEmployee.LastName = employee.LastName;
            existingEmployee.Email = employee.Email;
            existingEmployee.HireDate = employee.HireDate;
            existingEmployee.Salary = employee.Salary;

            // Upload new image (if selected)
            if (EmployeeImage != null && EmployeeImage.Length > 0)
            {
                var uploadFolder = Path.Combine(
                    Directory.GetCurrentDirectory(),
                    "wwwroot",
                    "uploads");

                if (!Directory.Exists(uploadFolder))
                {
                    Directory.CreateDirectory(uploadFolder);
                }

                // Delete old image (except NoImage.jpg)
                if (!string.IsNullOrEmpty(existingEmployee.ImagePath) &&
                    existingEmployee.ImagePath != "uploads/NoImage.jpg")
                {
                    var oldImage = Path.Combine(
                        Directory.GetCurrentDirectory(),
                        "wwwroot",
                        existingEmployee.ImagePath.Replace("/", Path.DirectorySeparatorChar.ToString()));

                    if (System.IO.File.Exists(oldImage))
                    {
                        System.IO.File.Delete(oldImage);
                    }
                }

                // Create new GUID filename
                var fileName = Guid.NewGuid().ToString() +
                               Path.GetExtension(EmployeeImage.FileName);

                var filePath = Path.Combine(uploadFolder, fileName);

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await EmployeeImage.CopyToAsync(stream);
                }

                existingEmployee.ImagePath = "uploads/" + fileName;
            }

            existingEmployee.UpdatedAt = DateTime.Now;

            await _context.SaveChangesAsync();

            return Ok(existingEmployee);
        }

        // DELETE: api/employees/14
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteEmployee(int id)
        {
            try
            {
                var employee = await _context.Employees.FindAsync(id);
                if (employee == null)
                {
                    return NotFound(new
                    {
                        message = $"Employee with ID {id} not found."
                    });
                }
                //These lines delete the employee from the Employees table
                _context.Employees.Remove(employee); //marks the employee for deletion
                await _context.SaveChangesAsync(); //removes the employee from the database
                return Ok(new
                {
                    message = $"Employee with ID {id} deleted successfully."
                });
            }
            catch (Exception)
            {
                return StatusCode(500, new
                {
                    message = "An error occurred while deleting the employee."
                });
            }
        }
    }
}